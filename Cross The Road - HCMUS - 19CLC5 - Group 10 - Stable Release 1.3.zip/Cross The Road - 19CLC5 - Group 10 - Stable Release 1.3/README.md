# 19clc5-group10-oop-project
Simple game project: Cross The Road
Created by Students of Ho Chi Minh University of Science - Faculty of IT
Class 19CLC5 - Group 10
Github accounts:
	- nvakiet
	- Qambitions
	- ptvinhkhue
	- thienxaso1st